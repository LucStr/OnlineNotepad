<?php
error_reporting(0); // DEACTIVATE ALL NOTICES
//error_reporting(E_ERROR | E_WARNING | E_PARSE);
require_once("include/constants.php");
?>
