<?php
$emailcheck = $session->getData('emailmessage');
$pwcheck = $session->getData('passwordmessage');
$loginversuch = $session->getData('loginattemptmessage');
$loggedInUser = $session->getData('userId');

$session->unsetData('emailmessage');
$session->unsetData('passwordmessage');
$session->unsetData('loginattemptmessage');
?>


<?php
if(!is_numeric($loggedInUser)) {
?>
<h2>Login</h2>

<div class="formDiv">
  <?php if($loginversuch==1 and is_numeric($loginversuch)) { echo "<p><b  style='color: red;'>Keine Übereinstimmung!</b></p>"; } ?>
  <!-- Action variable -->
   <form name="Login" enctype="multipart/form-data" action="?action=aLogin" method="post">
  	<p>E-Mail: <input name="theveryspecialemail" type="text"></p>
	  <?php if($emailcheck==0 and is_numeric($emailcheck)) { echo "<p><b style='color: red;'>E-Mail Adresse falsch! Bitte erneut eingeben.</b></p>"; } ?>
    <p>Password: <input name="theveryspecialpassword" type="password"></p>
    <?php if($pwcheck==0 and is_numeric($pwcheck)) { echo "<p><b style='color: red;'>Passwort falsch! Bitte erneut eingeben.</b></p>"; } ?>
  	<p><input name="submit" type="submit" value="Login"  /></p>
  </form>
</div>
<?php  } else { echo "<br><h3>Sie sind bereits erfolgreich eingeloggt ! </h3>"; }  ?>
