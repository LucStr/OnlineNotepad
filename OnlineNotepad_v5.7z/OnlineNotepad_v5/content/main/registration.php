<h1>Registration</h1>

<div class="formDiv">
  <form name="Register" enctype="multipart/form-data" action="?action=aRegister" method="post">
    <p>Vorname: <input name="firstname" type="text"></p>
    <p>Nachname: <input name="lastname" type="text" value=""></p>
    <p>Email: <input name="email" type="text" value=""><p/>
    <p>Passwort: <input name="passwort" type="password" value=""></p>
    <p><input name="submit" type="submit" value="Konto Erstellen"  /></p>
  </form>
</div>
