<h2>Online Notepad</h2>
Online Notepad is used for editing Textfiles with multiple Persons.
