<a class="navLink" href="?menu=mHome">Home</a>
<a class="navLink" href="?menu=mDocuments">Documents</a>
<a class="navLink" href="?menu=mLogin">Login</a>
<a class="navLink" href="?menu=mRegistration">Registration</a>
